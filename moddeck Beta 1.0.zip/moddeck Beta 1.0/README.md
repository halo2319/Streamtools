# ModDeck

One feed and one set of mod tools for every chat you moderate, across Twitch,
YouTube, Kick and TikTok. Made for moderators, not streamers.

## Setup (moderators and admins, same steps)

1. Install Node.js from https://nodejs.org (once). You also need Google Chrome or
   Microsoft Edge installed (most people already have one).
2. Double-click **Start ModDeck.bat** (Windows) or **Start ModDeck.command** (Mac).
   On Linux run `./start.sh`.
3. Your browser opens. Click **Sign in with Twitch / YouTube / Kick**. Your normal
   Chrome/Edge opens: log in with your username and password like you
   always do, then **close that window yourself**. ModDeck picks up your login as soon as it closes.

No developer apps, no client IDs, no tokens, no files to edit. Your login stays
in the `data/` folder on your computer (do not share that folder).

- **Twitch:** chats you moderate are found automatically if Twitch allows it; if the
  list is empty, add them in **Manage chats**.
- **YouTube:** when one of your streams goes live, open **Manage chats** and paste its link.
- **Kick:** open **Manage chats** and type the channel names you moderate.
- **TikTok:** type the username in **Manage chats**. Read-only (no sign-in).

## How it works, and the trade-off

ModDeck signs in the same way a person does, then reads and moderates chat through the
same web endpoints the platforms' own websites use. That is what removes the setup, but:

- These endpoints are **unofficial** and the platforms can change them at any time, which
  would break that platform until ModDeck is updated.
- It may go against the platforms' terms of service. Use it at your own risk.
- YouTube timeouts are a fixed 5 minutes (YouTube's choice). YouTube bans can only be
  undone in YouTube Studio. YouTube/Kick/Twitch everywhere-actions on YouTube only work for
  users who have chatted in that chat since ModDeck started.
- Google or Cloudflare may occasionally ask for extra verification in the sign-in window.
  Just complete it.
- Status: **not yet tested against live accounts.** Twitch moderation tries the official
  API first and falls back to the website's own calls; the Kick, Twitch-fallback and
  YouTube moderation endpoints are the likeliest to need small fixes.

## What you can do

| | Twitch | YouTube | Kick | TikTok |
|---|---|---|---|---|
| Read chat | yes | yes | yes (unofficial socket) | yes (unofficial library) |
| Find your chats automatically | yes | no, paste stream link | no, type name | no, type name |
| Send a chat message | yes | yes (200 characters max) | yes | no |
| Delete message | yes | yes | yes (verify endpoint) | no |
| Timeout | yes | yes | yes | no |
| Ban / unban | yes | yes (undo only for bans made here this session) | yes | no |
| Warn | yes | no | no | no |
| Messages removed by other mods disappear here | yes | yes | yes | no |

TikTok has no public API for moderating LIVE chat, so it is read-only, with a
button that opens the stream.

**Icons:** every message shows a small platform icon (Twitch, YouTube, Kick, TikTok)
so you can see where it came from.

**Combining streams:** once your streams are added, click **Combine** in the Streams list
on the left, tick two or more (for example one person live on Twitch, YouTube and Kick),
name it and click Combine. They become a single stream in the list, with the icons of its
platforms. Click it to see one merged chat, one video switcher with just those platforms, and
a send box option "All in <name>" that posts to every chat in it. Double-click its name to
rename it, **Split** to separate the streams again, and **All streams** to see everything. You
can also combine a combined stream with more streams. Combined streams are saved in your browser.

**Everywhere** (key `e`) bans, times out, warns or unbans one person on every
platform at once. ModDeck lists accounts with the same name (people who chatted
in your chats, plus a Twitch lookup) and you tick the ones you are sure about,
since the same name is not always the same person. Warnings are Twitch only.

**Video:** the stream is the main view. Switch between Twitch, YouTube, Kick and TikTok
with the tabs above the video, and pick the channel from the list. Chat and the mod tools
sit in the column on the right: click a message and the delete / timeout / ban buttons
appear right under the chat. With "Video follows the chat I click" ticked, clicking a message
switches the video to that stream. **This stream** shows only the chat of the video you are
watching, and **Hide video** gives the whole width to chat. Players start muted. TikTok does
not allow embedding, so it shows an "Open TikTok LIVE" button instead. If a YouTube stream will
not play, its owner may have disabled embedding: use "Open on site".

**Chat view:** the row of chips above the chat switches between **All streams** (every chat
merged, each message tagged with its platform icon and channel) and any single or combined
stream. When something is filtering the chat (a hidden platform or stream, **This stream**, a
person, a search) an amber bar says so, with a **Show all** button.

**Combined chat:** click **+ Combine** at the end of the chip row above the chat (it works at any window
width), tick two or more streams, name it and click Combine. The combined chat has its own chip, one merged
feed in time order, one video switcher, and a send box option "All in <n>" with **Send to:** platform
switches. Past messages (below) work in it too: scroll up for earlier ones, and messages filled in from the
platforms land in the right place in time. **Split** next to the chip separates it again.

**Past messages:** ModDeck remembers the last 5000 messages (up to 7 days) in `data/history.json`,
so they are still there after a restart. The chat shows the latest ones; scroll to the top or click
**Show earlier messages** to load more. Older messages show their date. When ModDeck joins a chat it also
fills in what was said before, on every platform: YouTube hands over its recent chat, Twitch
is asked for its recent messages through the community "recent messages" service
(recent-messages.robotty.de, only the channel name is sent), Kick is asked for its recent messages
through kick.com's own chat history call, and TikTok passes on the messages sent just before
ModDeck connected. These calls are unofficial: if one fails, live chat is unaffected and that
platform's history simply starts when ModDeck starts. The platforms only keep a few hundred recent messages,
so how far back you get depends on them; everything ModDeck has seen is kept in `data/history.json`.

**Sending to several chats:** in a combined chat a **Send to:** row of platform switches sits above the
send box. Switch a platform on or off to choose where the message goes: one platform, a few, or all (the
dropdown follows along as "All in <n>"). A chat that is not live yet is skipped quietly, without an error
pop-up.

Other features: filter by platform or chat, search, click a name to see only that
person, watch-word highlighting, a log of your actions, and "also in my other
chats" for repeat offenders.

## Keys

`j` / `k` move, `d` delete, `t` timeout, `w` warn, `b` ban (press twice),
`e` everywhere, `c` chat box, `/` search, `Esc` clear.

## Safety

- The dashboard only listens on localhost and refuses connections from other websites.
- Your sign-in sessions are stored in `data/` on your computer. Do not share that folder.
- Using unofficial chat readers (Kick socket, TikTok library) may go against those platforms' terms.
- Status: first version, not yet tested against live accounts. The Kick message and delete
  endpoints are the likeliest to need small fixes.
