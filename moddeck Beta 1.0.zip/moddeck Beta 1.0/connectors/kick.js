// Kick: signed in as the moderator's own browser session. Moderation calls use the
// session cookies from that login.
// Reading chat uses Kick's chat websocket (Pusher). All of this is unofficial and can
// change without notice.
const crypto = require('crypto');
const WebSocket = require('ws');
const session = require('../lib/session');

// Kick retired its old chat key (32cbd69e...) in October 2026 and answers it with Pusher error 4001.
// ModDeck asks Kick for the current chat server the way kick.com's own page does, and falls back to
// the key Kick was handing out when this was written.
const FALLBACK = { key: '34bf7a0ff419a2a775b9', cluster: 'us2' };
const pusherUrl = (c) => `wss://ws-${c.cluster}.pusher.com/app/${c.key}?protocol=7&client=js&version=8.4.0&flash=false`;

module.exports = ({ config, emit, status }) => {
  const cfg = config.kick;
  const rooms = {}; // slug -> { broadcasterId, chatroomId }
  const bySlug = (s) => rooms[s];
  let ws, stopped = true, timer, retry = 0;
  let cred = { ...FALLBACK }, refused = false;

  // Ask Kick which chat server to use. The answer goes into a web address, so it is checked strictly.
  async function resolveCreds() {
    try {
      const r = await fetch('https://web.kick.com/api/v1/realtime/connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': session.ua('kick'), Origin: 'https://kick.com', Referer: 'https://kick.com/' },
        body: JSON.stringify({ client: { id: crypto.randomUUID(), type: 'web' }, capabilities: { accepted_providers: [{ provider: 'pusher' }] } }),
      });
      if (!r.ok) throw new Error('Kick answered ' + r.status);
      const j = await r.json();
      const list = j?.data?.connections || j?.connections || [];
      const c = list.find((x) => /pusher/i.test(x.provider || '')) || list[0] || {};
      const cr = c.credentials || c;
      const key = cr.app_key || cr.appKey || cr.key, cluster = cr.cluster;
      if (/^[a-f0-9]{16,40}$/.test(key || '') && /^[a-z0-9-]{2,16}$/.test(cluster || '')) {
        cred = { key, cluster };
        console.log('[kick] chat server from Kick:', cluster, key);
      } else console.log('[kick] Kick did not offer a Pusher chat server, using built-in. Answer:', JSON.stringify(j).slice(0, 300));
    } catch (e) { console.warn('[kick] could not ask Kick for its chat server, using built-in:', e.message); }
  }

  async function api(method, path, body) {
    const ck = await session.cookies('kick');
    const dec = (n) => { const v = ck.find((c) => c.name === n)?.value; return v ? decodeURIComponent(v) : ''; };
    const r = await fetch('https://kick.com' + path, {
      method,
      headers: {
        Accept: 'application/json', 'Content-Type': 'application/json', 'User-Agent': session.ua('kick'),
        Origin: 'https://kick.com', Referer: 'https://kick.com/',
        Authorization: 'Bearer ' + dec('session_token'), 'X-XSRF-TOKEN': dec('XSRF-TOKEN'),
        Cookie: ck.filter((c) => c.domain.replace(/^\./, '').endsWith('kick.com')).map((c) => `${c.name}=${c.value}`).join('; '),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await r.text();
    let j = {}; try { j = JSON.parse(text); } catch {}
    if (r.status === 403 && /cloudflare|just a moment/i.test(text)) throw new Error('Kick blocked the request (Cloudflare). Sign in again.');
    if (!r.ok) throw new Error(`Kick ${r.status}: ${j.message || j.error || text.slice(0, 100)}`);
    return j;
  }

  async function check(slug) {
    const j = await api('GET', '/api/v2/channels/' + encodeURIComponent(slug)).catch(() => null);
    if (!j || !j.chatroom) throw new Error('Kick has no channel called ' + slug);
  }

  async function resolve(ch) {
    const j = await api('GET', '/api/v2/channels/' + encodeURIComponent(ch.slug));
    const chatroomId = j.chatroom?.id || ch.chatroomId || 0;
    if (chatroomId) ch.chatroomId = chatroomId;
    rooms[ch.slug] = { chatroomId, channelId: j.id || 0 };
    if (!chatroomId) status('kick', 'error', `Can't read ${ch.slug}'s chat yet.`);
  }

  async function start() {
    stopped = false;
    if (!session.loggedIn('kick')) return status('kick', 'login', 'Sign in with your moderator account');
    status('kick', 'connecting');
    for (const ch of cfg.channels || []) await resolve(ch).catch((e) => console.warn('[kick]', ch.slug, e.message));
    await resolveCreds();
    connect();
  }

  function slugForRoom(id) {
    return Object.keys(rooms).find((s) => String(rooms[s].chatroomId) === String(id));
  }

  function emitMsg(slug, d) {
    if (!d || !d.id || !d.sender || d.sender.id == null || typeof d.content !== 'string') return;
    const badges = (d.sender.identity?.badges || []).map((b) => b.type);
    emit({
      type: 'chat', id: 'kick:' + d.id, mid: d.id, platform: 'kick', channel: slug,
      userId: String(d.sender.id), user: d.sender.username, text: d.content,
      ts: Date.parse(d.created_at) || Date.now(),
      isMod: badges.some((b) => b === 'moderator' || b === 'broadcaster'),
    });
  }

  // Kick's chat socket only sends new messages. Ask Kick's website for the recent ones, the way kick.com's
  // own chat does when you open it, so past messages show up too. Unofficial: failures are ignored.
  async function backfill() {
    for (const [slug, room] of Object.entries({ ...rooms })) {
      if (stopped) return;
      const paths = [room.channelId && `/api/v2/channels/${room.channelId}/messages`, room.chatroomId && `/api/v2/chatrooms/${room.chatroomId}/messages`].filter(Boolean);
      for (const p of paths) {
        try {
          const j = await api('GET', p);
          const list = j?.data?.messages || j?.messages || (Array.isArray(j?.data) ? j.data : null);
          if (Array.isArray(list) && list.length) { list.forEach((d) => emitMsg(slug, d)); break; }
        } catch {}
      }
      await new Promise((res) => setTimeout(res, 300));
    }
  }

  function connect() {
    if (stopped) return;
    refused = false;
    ws = new WebSocket(pusherUrl(cred));
    ws.on('message', (raw) => {
      let m; try { m = JSON.parse(raw); } catch { return; }
      let d = m.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch {} }
      switch (m.event) {
        case 'pusher:connection_established':
          retry = 0;
          backfill();
          for (const r of Object.values(rooms)) if (r.chatroomId) ws.send(JSON.stringify({ event: 'pusher:subscribe', data: { auth: '', channel: `chatrooms.${r.chatroomId}.v2` } }));
          status('kick', 'live');
          break;
        case 'pusher:error':
          if (d && d.code >= 4000 && d.code < 4100) { refused = true; console.warn('[kick] chat server refused ModDeck:', d.code, d.message); }
          break;
        case 'pusher:ping': ws.send(JSON.stringify({ event: 'pusher:pong', data: {} })); break;
        case 'App\\Events\\ChatMessageEvent': {
          const slug = slugForRoom(d.chatroom_id);
          if (!slug) break;
          emitMsg(slug, d);
          break;
        }
        case 'App\\Events\\MessageDeletedEvent': emit({ type: 'removed', id: 'kick:' + (d.message?.id || d.id) }); break;
        case 'App\\Events\\UserBannedEvent': {
          const slug = slugForRoom(String(m.channel || '').split('.')[1]);
          if (slug && d.user?.id) emit({ type: 'userRemoved', platform: 'kick', channel: slug, userId: String(d.user.id) });
          break;
        }
      }
    });
    ws.on('close', () => {
      if (stopped) return;
      status('kick', 'connecting', refused ? "Kick's chat server refused the connection, asking Kick for a new one" : 'Reconnecting');
      timer = setTimeout(async () => { if (stopped) return; if (refused) await resolveCreds(); connect(); }, Math.min(30000, 1000 * 2 ** retry++));
    });
    ws.on('error', (e) => status('kick', 'error', e.message));
  }

  function stop() {
    stopped = true;
    clearTimeout(timer);
    if (ws) { ws.removeAllListeners(); try { ws.close(); } catch {} }
  }

  async function act({ kind, duration, reason, all }, msg) {
    const targets = all && kind !== 'delete' ? Object.keys(rooms) : [msg.channel];
    const out = [];
    for (const slug of targets) {
      try {
        const room = bySlug(slug);
        if (!room) throw new Error('Unknown channel');
        const chan = '/api/v2/channels/' + encodeURIComponent(slug);
        if (kind === 'timeout') await api('POST', chan + '/bans', { banned_username: msg.user, duration: Math.min(10080, Math.max(1, Math.ceil(duration / 60))), reason, permanent: false });
        else if (kind === 'ban') await api('POST', chan + '/bans', { banned_username: msg.user, reason, permanent: true });
        else if (kind === 'unban') await api('DELETE', chan + '/bans/' + encodeURIComponent(msg.user));
        else if (kind === 'delete') await api('DELETE', `/api/v2/chatrooms/${room.chatroomId}/messages/${encodeURIComponent(msg.mid)}`);
        else throw new Error('Not supported on Kick');
        out.push({ channel: slug, ok: true });
      } catch (e) { out.push({ channel: slug, ok: false, error: e.message }); }
    }
    return out;
  }

  async function say(slug, text) {
    const room = bySlug(slug);
    if (!room || !room.chatroomId) throw new Error('Unknown channel');
    await api('POST', `/api/v2/messages/send/${room.chatroomId}`, { content: text, type: 'message' });
  }

  return { start, stop, act, say, check, restart: async () => { stop(); await start(); } };
};
