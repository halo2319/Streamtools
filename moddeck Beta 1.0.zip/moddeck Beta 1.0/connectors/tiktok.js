// TikTok: READ-ONLY. TikTok has no public moderation API for LIVE chat, so
// this connector only shows messages. Mods still act inside the TikTok app,
// and the dashboard gives a one-click link to the stream.
// Chat comes from the unofficial "tiktok-live-connector" package, which is
// not endorsed by TikTok and can break or be blocked at any time.
module.exports = ({ config, emit, status }) => {
  const cfg = config.tiktok;
  const conns = new Map();
  let stopped = true;

  // TikTok's own time for the message (milliseconds), so earlier messages sort into place; now if it has none
  const stampMs = (t) => { const n = Number(t); return n > 1e12 ? n : n > 1e9 ? n * 1000 : Date.now(); };

  let lib = null;
  try { lib = require('tiktok-live-connector'); } catch {}
  const Conn = lib && (lib.TikTokLiveConnection || lib.WebcastPushConnection);

  async function open(name) {
    if (stopped) return;
    const c = new Conn(name, { processInitialData: true }); // also hands over messages sent just before we connected
    conns.set(name, c);
    c.on('chat', (d) => {
      const u = d.user || d;
      emit({
        type: 'chat', id: 'tiktok:' + (d.msgId || `${name}-${Date.now()}-${Math.random()}`), mid: String(d.msgId || ''),
        platform: 'tiktok', channel: name, userId: String(u.userId || u.uniqueId || ''),
        user: u.nickname || u.uniqueId || 'unknown', text: d.comment || '', ts: stampMs(d.createTime), isMod: false,
        url: `https://www.tiktok.com/@${name}/live`,
      });
    });
    const retry = () => { if (!stopped) setTimeout(() => open(name), 30000); };
    c.on('disconnected', retry);
    try { await c.connect(); status('tiktok', 'live', 'read-only'); }
    catch (e) { status('tiktok', 'live', `waiting for @${name} to go live`); retry(); }
  }

  async function start() {
    stopped = false;
    if (!Conn) return status('tiktok', 'error', 'Run: npm install tiktok-live-connector');
    status('tiktok', 'connecting');
    for (const c of cfg.channels || []) open(c.replace(/^@/, ''));
  }

  function stop() {
    stopped = true;
    for (const c of conns.values()) { try { c.disconnect(); } catch {} }
    conns.clear();
  }

  async function act(_action, msg) {
    return [{ channel: msg.channel, ok: false, error: 'TikTok has no moderation API. Use the TikTok app.' }];
  }

  async function say() { throw new Error('TikTok has no chat API. Use the TikTok app.'); }

  return { start, stop, act, say, restart: async () => { stop(); await start(); } };
};
