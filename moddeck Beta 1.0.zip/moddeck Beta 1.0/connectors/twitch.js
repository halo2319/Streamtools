// Twitch: chat over IRC-WebSocket, moderation through the official Helix API.
const WebSocket = require('ws');
const session = require('../lib/session');

// Twitch's own website client ID: the logged-in browser session's token belongs to it.
const WEB_ID = 'kimne78kx3ncx6brgo4mv6wki5h1ko';

const unesc = (s) => s.replace(/\\s/g, ' ').replace(/\\:/g, ';').replace(/\\\\/g, '\\');

function parse(line) {
  const tags = {};
  let rest = line;
  if (rest[0] === '@') {
    const i = rest.indexOf(' ');
    rest.slice(1, i).split(';').forEach((kv) => { const [k, v] = kv.split('='); tags[k] = v || ''; });
    rest = rest.slice(i + 1);
  }
  let prefix = '';
  if (rest[0] === ':') { const i = rest.indexOf(' '); prefix = rest.slice(1, i); rest = rest.slice(i + 1); }
  let trailing = '';
  const t = rest.indexOf(' :');
  if (t >= 0) { trailing = rest.slice(t + 2); rest = rest.slice(0, t); }
  const [cmd, ...params] = rest.split(' ');
  return { tags, prefix, cmd, params, trailing };
}

module.exports = ({ config, emit, status }) => {
  const cfg = config.twitch;
  const clean = (c) => c.replace(/^#/, '').toLowerCase();
  const DEFAULT_JOIN = 30; // chats joined automatically when a mod has more than this
  let channels = [], listing = [];
  let me = null;
  let ws, ids = {}, stopped = true, timer, retry = 0, joins = [];
  let helixDead = false; // Twitch answers 404 to Helix for the website login: use the website's own calls

  async function identity() {
    const token = await session.cookie('twitch', 'auth-token');
    if (!token) return null;
    if (me && me.token === token) return me;
    const r = await fetch('https://id.twitch.tv/oauth2/validate', { headers: { Authorization: 'OAuth ' + token } });
    if (!r.ok) return null;
    const j = await r.json();
    return (me = { token, login: j.login, user_id: j.user_id });
  }

  async function api(method, path, query, body) {
    if (helixDead) throw new Error('Twitch Helix unavailable for this login');
    const t = await identity();
    if (!t) { status('twitch', 'login', 'Please sign in again'); throw new Error('Not signed in to Twitch'); }
    const url = new URL('https://api.twitch.tv/helix' + path);
    for (const [k, v] of Object.entries(query || {})) [].concat(v).forEach((x) => url.searchParams.append(k, x));
    const r = await fetch(url, {
      method,
      headers: { Authorization: 'Bearer ' + t.token, 'Client-Id': WEB_ID, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    const j = await r.json().catch(() => ({})); // DELETE returns 204
    if (r.status === 404) helixDead = true;
    if (!r.ok) throw new Error(`Twitch ${r.status} on ${path}: ${j.message || j.error || 'no details'}`);
    return j;
  }

  // Fallback: the same internal GraphQL calls twitch.com makes. Needs no special permissions.
  async function gql(query, variables) {
    const t = await identity();
    if (!t) throw new Error('Not signed in to Twitch');
    const r = await fetch('https://gql.twitch.tv/gql', {
      method: 'POST', headers: { 'Client-Id': WEB_ID, Authorization: 'OAuth ' + t.token, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
    });
    const j = await r.json().catch(() => ({}));
    const e = Array.isArray(j) ? j[0] : j;
    if (!r.ok || e.errors) throw new Error(e.errors?.[0]?.message || e.message || 'Twitch error ' + r.status);
    return e.data;
  }

  const GQL = {
    ban: 'mutation($input: BanUserFromChatRoomInput!){ banUserFromChatRoom(input:$input){ error{ code } } }',
    unban: 'mutation($input: UnbanUserFromChatRoomInput!){ unbanUserFromChatRoom(input:$input){ error{ code } } }',
    delete: 'mutation($input: DeleteChatMessageInput!){ deleteChatMessage(input:$input){ responseCode } }',
  };
  async function gqlAct(kind, channelId, msg, duration, reason) {
    const who = (msg.user || '').toLowerCase();
    let d;
    if (kind === 'delete') d = await gql(GQL.delete, { input: { channelID: channelId, messageID: msg.mid } });
    else if (kind === 'unban') d = await gql(GQL.unban, { input: { channelID: channelId, bannedUserLogin: who } });
    else d = await gql(GQL.ban, { input: { channelID: channelId, bannedUserLogin: who, reason: reason || '', ...(kind === 'timeout' ? { expiresIn: duration + 's' } : {}) } });
    const code = Object.values(d || {})[0]?.error?.code;
    if (code) throw new Error('Twitch: ' + code);
  }

  // Look up accounts by login. Helix first; if Twitch refuses it for this session, use the website's own GraphQL.
  async function users(logins) {
    try {
      const out = [];
      for (let i = 0; i < logins.length; i += 100) {
        const j = await api('GET', '/users', { login: logins.slice(i, i + 100) });
        out.push(...(j.data || []));
      }
      return out;
    } catch (e) {
      console.warn('[twitch] helix user lookup failed, using website lookup:', e.message);
      const out = [];
      for (const l of logins) {
        const d = await gql('query($l:String!){ user(login:$l){ id login displayName } }', { l });
        if (d && d.user) out.push({ id: d.user.id, login: d.user.login, display_name: d.user.displayName });
      }
      return out;
    }
  }

  async function start() {
    stopped = false;
    if (!session.loggedIn('twitch')) return status('twitch', 'login', 'Sign in with your moderator account');
    status('twitch', 'connecting');
    const t = await identity();
    if (!t) return status('twitch', 'login', 'Please sign in again');
    ids = {};
    const discovered = [];
    try { // every channel this account moderates
      let after;
      do {
        const j = await api('GET', '/moderation/channels', { user_id: t.user_id, first: 100, ...(after ? { after } : {}) });
        for (const c of j.data || []) { const l = clean(c.broadcaster_login); discovered.push(l); ids[l] = c.broadcaster_id; }
        after = j.pagination && j.pagination.cursor;
      } while (after);
    } catch (e) { console.warn('[twitch] could not list moderated channels:', e.message); status('twitch', 'connecting', 'Add the chats you moderate in Manage chats'); }
    const extras = (cfg.channels || []).map(clean);
    const all = [...new Set([...discovered, ...extras])];
    const on = new Set((cfg.on || [...discovered.slice(0, DEFAULT_JOIN), ...extras]).map(clean));
    channels = all.filter((c) => on.has(c));
    listing = all.map((c) => ({ channel: c, on: on.has(c), source: discovered.includes(c) ? 'moderated' : 'added', key: c }));
    const unknown = channels.filter((c) => !ids[c]);
    (await users(unknown)).forEach((u) => { ids[u.login] = u.id; });
    connect();
  }

  // Twitch does not send messages from before you joined. The community "recent messages" service keeps
  // the last few hundred per chat; ask it so past messages show up too. Failures are ignored.
  async function backfill(list) {
    for (const c of list.slice(0, 40)) {
      if (stopped) return;
      try {
        const r = await fetch(`https://recent-messages.robotty.de/api/v2/recent-messages/${encodeURIComponent(c)}?limit=300`, { signal: AbortSignal.timeout(8000) });
        if (r.ok) for (const line of (await r.json()).messages || []) if (/ PRIVMSG #/.test(line)) { try { handle(line); } catch {} }
      } catch {}
      await new Promise((res) => setTimeout(res, 300));
    }
  }

  function connect() {
    const t = me;
    if (!t || stopped) return;
    ws = new WebSocket('wss://irc-ws.chat.twitch.tv:443');
    ws.on('open', () => {
      ws.send('CAP REQ :twitch.tv/tags twitch.tv/commands');
      ws.send('PASS oauth:' + t.token);
      ws.send('NICK ' + t.login);
      // Twitch allows ~20 joins per 10 seconds
      channels.forEach((c, i) => joins.push(setTimeout(() => ws.readyState === 1 && ws.send('JOIN #' + c), Math.floor(i / 15) * 10500)));
      backfill(channels.slice());
    });
    ws.on('message', (d) => d.toString().split('\r\n').filter(Boolean).forEach(handle));
    ws.on('close', () => {
      if (stopped) return;
      status('twitch', 'connecting', 'Reconnecting');
      timer = setTimeout(connect, Math.min(30000, 1000 * 2 ** retry++));
    });
    ws.on('error', (e) => status('twitch', 'error', e.message));
  }

  function handle(line) {
    const m = parse(line);
    switch (m.cmd) {
      case 'PING': ws.send('PONG :' + m.trailing); break;
      case '001': retry = 0; status('twitch', 'live', `as ${me.login}, ${channels.length} of ${listing.length} chats`); break;
      case 'RECONNECT': ws.close(); break;
      case 'NOTICE':
        if (/authentication failed/i.test(m.trailing)) { me = null; status('twitch', 'login', 'Twitch rejected the login. Sign in again.'); }
        break;
      case 'PRIVMSG': {
        let text = m.trailing, action = false;
        const a = text.match(/^\x01ACTION (.*)\x01$/);
        if (a) { text = a[1]; action = true; }
        emit({
          type: 'chat', id: 'twitch:' + m.tags.id, mid: m.tags.id, platform: 'twitch',
          channel: m.params[0].slice(1), userId: m.tags['user-id'],
          user: unesc(m.tags['display-name'] || m.prefix.split('!')[0]),
          text, action, ts: Number(m.tags['tmi-sent-ts']) || Date.now(),
          isMod: /moderator|broadcaster/.test(m.tags.badges || ''),
        });
        break;
      }
      case 'CLEARMSG': emit({ type: 'removed', id: 'twitch:' + m.tags['target-msg-id'] }); break;
      case 'CLEARCHAT':
        if (m.tags['target-user-id']) emit({ type: 'userRemoved', platform: 'twitch', channel: m.params[0].slice(1), userId: m.tags['target-user-id'] });
        break;
    }
  }

  async function lookup(name) {
    const u = (await users([name.toLowerCase()]))[0];
    return u ? { userId: u.id, user: u.display_name } : null;
  }

  async function say(channel, text) {
    if (!ws || ws.readyState !== 1) throw new Error('Not connected to Twitch chat yet');
    if (!ids[channel]) throw new Error('Unknown channel');
    ws.send(`PRIVMSG #${channel} :${text}`);
  }

  function stop() {
    stopped = true;
    clearTimeout(timer);
    joins.forEach(clearTimeout); joins = [];
    channels = []; listing = [];
    if (ws) { ws.removeAllListeners(); try { ws.close(); } catch {} }
  }

  async function act({ kind, duration, reason, all }, msg) {
    const targets = all && kind !== 'delete' ? channels : [msg.channel];
    const out = [];
    for (const ch of targets) {
      try {
        if (!ids[ch]) throw new Error('Unknown channel');
        const q = { broadcaster_id: ids[ch], moderator_id: me.user_id };
        const helix = async () => {
          if (kind === 'delete') await api('DELETE', '/moderation/chat', { ...q, message_id: msg.mid });
          else if (kind === 'timeout') await api('POST', '/moderation/bans', q, { data: { user_id: msg.userId, duration, reason } });
          else if (kind === 'ban') await api('POST', '/moderation/bans', q, { data: { user_id: msg.userId, reason } });
          else if (kind === 'unban') await api('DELETE', '/moderation/bans', { ...q, user_id: msg.userId });
          else if (kind === 'warn') await api('POST', '/moderation/warnings', q, { data: { user_id: msg.userId, reason: reason || 'Please follow the chat rules.' } });
          else throw new Error('Not supported on Twitch');
        };
        if (kind === 'warn') await helix();
        else { try { await helix(); } catch (e) { try { await gqlAct(kind, ids[ch], msg, duration, reason); } catch (e2) { throw new Error(e2.message); } } }
        out.push({ channel: ch, ok: true });
      } catch (e) { out.push({ channel: ch, ok: false, error: e.message }); }
    }
    return out;
  }

  return { start, stop, act, say, lookup, list: () => listing, restart: async () => { stop(); await start(); } };
};
