// YouTube: reads and moderates live chat through the same web endpoints youtube.com
// itself uses, signed in as the moderator's own session (no API key, no quota).
// These are unofficial and can change without notice.
const crypto = require('crypto');
const session = require('../lib/session');

const ORIGIN = 'https://www.youtube.com';

function extractJson(html, marker) {
  const i = html.indexOf(marker);
  if (i < 0) return null;
  const s = html.indexOf('{', i);
  let depth = 0, str = false, esc = false;
  for (let k = s; k < html.length; k++) {
    const ch = html[k];
    if (str) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') str = false; continue; }
    if (ch === '"') str = true;
    else if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) { try { return JSON.parse(html.slice(s, k + 1)); } catch { return null; } }
  }
  return null;
}
const runsText = (m) => (m?.runs || []).map((r) => r.text ?? r.emoji?.shortcuts?.[0] ?? r.emoji?.emojiId ?? '').join('') || m?.simpleText || '';

module.exports = ({ config, emit, status }) => {
  const cfg = config.youtube;
  const chats = new Map(); // name -> { videoId, st }
  const ctxParams = new Map(); // message id -> context-menu params
  const lastByUser = new Map(); // `${chat}:${userId}` -> params
  let stopped = true;

  async function authHeaders() {
    const ck = await session.cookies('youtube');
    const get = (n) => ck.find((c) => c.name === n)?.value;
    const ts = Math.floor(Date.now() / 1000);
    const h = (sid) => `${ts}_${crypto.createHash('sha1').update(`${ts} ${sid} ${ORIGIN}`).digest('hex')}`;
    const parts = [];
    if (get('SAPISID')) parts.push('SAPISIDHASH ' + h(get('SAPISID')));
    if (get('__Secure-1PAPISID')) parts.push('SAPISID1PHASH ' + h(get('__Secure-1PAPISID')));
    if (get('__Secure-3PAPISID')) parts.push('SAPISID3PHASH ' + h(get('__Secure-3PAPISID')));
    return {
      Authorization: parts.join(' '), 'X-Origin': ORIGIN, 'X-Goog-AuthUser': '0', 'User-Agent': session.ua('youtube'),
      'Content-Type': 'application/json',
      Cookie: ck.filter((c) => /(youtube|google)\.com$/.test(c.domain.replace(/^\./, ''))).map((c) => `${c.name}=${c.value}`).join('; '),
    };
  }

  async function post(st, path, body, query = '') {
    const r = await fetch(`${ORIGIN}/youtubei/v1/${path}?key=${st.key}&prettyPrint=false${query}`, {
      method: 'POST', headers: await authHeaders(),
      body: JSON.stringify({ context: { client: { clientName: 'WEB', clientVersion: st.version, hl: 'en' } }, ...body }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error?.message || 'YouTube error ' + r.status);
    return j;
  }

  async function describe(videoId) {
    const r = await fetch(`${ORIGIN}/oembed?format=json&url=${encodeURIComponent(ORIGIN + '/watch?v=' + videoId)}`);
    if (!r.ok) throw new Error('YouTube could not find that video');
    return { name: (await r.json()).author_name };
  }

  async function init(ch) {
    const r = await fetch(`${ORIGIN}/live_chat?is_popout=1&v=${ch.videoId}`, { headers: await authHeaders() });
    const html = await r.text();
    const data = extractJson(html, 'ytInitialData');
    const lc = data?.contents?.liveChatRenderer;
    if (!lc) return null; // not live (yet) or chat closed
    const c = lc.continuations?.[0] || {};
    const cont = (c.invalidationContinuationData || c.timedContinuationData || c.reloadContinuationData || {}).continuation;
    return {
      key: (html.match(/"INNERTUBE_API_KEY":"([^"]+)"/) || [])[1],
      version: (html.match(/"INNERTUBE_CONTEXT_CLIENT_VERSION":"([^"]+)"/) || [])[1] || '2.20240101.00.00',
      continuation: cont, actions: lc.actions || [],
      sendParams: lc.actionPanel?.liveChatMessageInputRenderer?.sendButton?.buttonRenderer?.serviceEndpoint?.sendLiveChatMessageEndpoint?.params,
    };
  }

  function handle(ch, actions) {
    for (const a of actions) {
      const item = a.addChatItemAction?.item;
      const rd = item?.liveChatTextMessageRenderer || item?.liveChatPaidMessageRenderer;
      if (rd) {
        const params = rd.contextMenuEndpoint?.liveChatItemContextMenuEndpoint?.params;
        if (params) {
          ctxParams.set(rd.id, params); lastByUser.set(`${ch.name}:${rd.authorExternalChannelId}`, params);
          if (ctxParams.size > 4000) ctxParams.delete(ctxParams.keys().next().value);
        }
        const badges = (rd.authorBadges || []).map((b) => b.liveChatAuthorBadgeRenderer?.tooltip || '');
        emit({
          type: 'chat', id: 'youtube:' + rd.id, mid: rd.id, platform: 'youtube', channel: ch.name,
          userId: rd.authorExternalChannelId, user: rd.authorName?.simpleText || 'unknown',
          text: runsText(rd.message) || runsText(rd.headerSubtext), ts: Math.floor(Number(rd.timestampUsec) / 1000) || Date.now(),
          isMod: badges.some((b) => /moderator|owner/i.test(b)),
        });
      }
      const del = a.markChatItemAsDeletedAction?.targetItemId || a.removeChatItemAction?.targetItemId;
      if (del) emit({ type: 'removed', id: 'youtube:' + del });
      const by = a.markChatItemsByAuthorAsDeletedAction?.externalChannelId;
      if (by) emit({ type: 'userRemoved', platform: 'youtube', channel: ch.name, userId: by });
    }
  }

  async function loop(ch) {
    if (stopped || !chats.has(ch.name)) return;
    const entry = chats.get(ch.name);
    let wait = 5000;
    try {
      if (!entry.st) {
        entry.st = await init(ch);
        if (entry.st) { handle(ch, entry.st.actions); entry.st.actions = []; }
        else wait = 60000;
      }
      if (entry.st) {
        const j = await post(entry.st, 'live_chat/get_live_chat', { continuation: entry.st.continuation });
        const lc = j.continuationContents?.liveChatContinuation;
        if (!lc) throw Object.assign(new Error('chat ended'), { ended: true });
        const c = lc.continuations?.[0] || {};
        const n = c.invalidationContinuationData || c.timedContinuationData || c.reloadContinuationData;
        if (!n) throw Object.assign(new Error('chat ended'), { ended: true });
        entry.st.continuation = n.continuation;
        wait = Math.max(3000, n.timeoutMs || 5000);
        handle(ch, lc.actions || []);
      }
      const found = [...chats.values()].filter((c) => c.st).length;
      status('youtube', 'live', entry.st ? `${found}/${chats.size} chats found` : `waiting for ${ch.name} to go live`);
    } catch (e) {
      if (e.ended) { entry.st = null; wait = 60000; }
      else { status('youtube', 'error', e.message); wait = 30000; }
    }
    entry.timer = setTimeout(() => loop(ch), wait);
  }

  async function start() {
    stopped = false;
    if (!session.loggedIn('youtube')) return status('youtube', 'login', 'Sign in with your moderator Google account');
    status('youtube', 'connecting');
    if (!(cfg.channels || []).length) status('youtube', 'live', 'signed in. Add a live stream in Manage chats');
    for (const ch of cfg.channels || []) { chats.set(ch.name, { st: null, timer: null }); loop(ch); }
  }

  function stop() {
    stopped = true;
    for (const c of chats.values()) clearTimeout(c.timer);
    chats.clear();
  }

  const ICONS = { delete: /^DELETE$/, ban: /^REMOVE_CIRCLE$|^BLOCK$/, timeout: /^HOURGLASS|^TIMER|^CLOCK/ };
  const TEXTS = { delete: /remove|delete/i, ban: /hide user|block|ban/i, timeout: /timeout/i };

  async function moderate(kind, params, st) {
    const menu = await post(st, 'live_chat/get_item_context_menu', {}, '&params=' + encodeURIComponent(params));
    const items = (menu.liveChatItemContextMenuSupportedRenderers?.menuRenderer?.items || []).map((i) => i.menuServiceItemRenderer).filter(Boolean);
    const it = items.find((i) => ICONS[kind].test(i.icon?.iconType || '')) || items.find((i) => TEXTS[kind].test(runsText(i.text)));
    const p = it?.serviceEndpoint?.moderateLiveChatEndpoint?.params;
    if (!p) throw new Error("YouTube didn't offer that action here (are you a moderator of this chat?)");
    await post(st, 'live_chat/moderate', { params: p });
  }

  async function act({ kind, all }, msg) {
    if (kind === 'unban') return [{ channel: msg.channel, ok: false, error: 'Undo bans in YouTube Studio (Community > Hidden users)' }];
    if (kind === 'warn') return [{ channel: msg.channel, ok: false, error: 'Not supported on YouTube' }];
    const targets = all && kind !== 'delete' ? [...chats.keys()] : [msg.channel];
    const out = [];
    for (const name of targets) {
      try {
        const entry = chats.get(name);
        if (!entry || !entry.st) throw new Error(name + ' is not live yet');
        const params = kind === 'delete' ? ctxParams.get(msg.mid) : (lastByUser.get(`${name}:${msg.userId}`) || (name === msg.channel ? ctxParams.get(msg.mid) : null));
        if (!params) throw new Error('No recent message from that user here');
        await moderate(kind, params, entry.st);
        out.push({ channel: name, ok: true });
      } catch (e) { out.push({ channel: name, ok: false, error: e.message }); }
    }
    return out;
  }

  async function say(channel, text) {
    const entry = chats.get(channel);
    if (!entry || !entry.st) throw new Error(channel + ' is not live yet');
    if (!entry.st.sendParams) throw new Error('YouTube chat is not open for you (sign in again?)');
    await post(entry.st, 'live_chat/send_message', {
      richMessage: { textSegments: [{ text }] }, clientMessageId: crypto.randomUUID(), params: entry.st.sendParams,
    });
  }

  return { start, stop, act, say, describe, restart: async () => { stop(); await start(); } };
};
