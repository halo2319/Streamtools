// ModDeck: one local dashboard for moderating many chats on many platforms.
// Runs on the moderator's own computer. Nothing is sent anywhere except to the platforms.
const http = require('http');
const fs = require('fs');
const path = require('path');

let WebSocketServer;
try { ({ WebSocketServer } = require('ws')); } catch { console.error('Run "npm install" first.'); process.exit(1); }

// Diagnostics only: print what Kick's chat socket does (open, messages, close code). Changes nothing.
const WSClass = require('ws');
const origEmit = WSClass.prototype.emit;
WSClass.prototype.emit = function (ev, ...a) {
  try {
    if (/pusher\.com/.test(this.url || '')) {
      if (ev === 'open') console.log('[kick-ws] open');
      else if (ev === 'message') console.log('[kick-ws] message', String(a[0]).slice(0, 160));
      else if (ev === 'error') console.log('[kick-ws] error', a[0] && a[0].message);
      else if (ev === 'close') console.log('[kick-ws] closed', a[0], String(a[1] || ''));
    }
  } catch {}
  return origEmit.call(this, ev, ...a);
};

const session = require('./lib/session');
const store = require('./lib/store');

const PORT = Number(process.env.PORT) || 3000;
const D = store.data; // always mutate D's properties; never reassign D

// Live settings handed to the connectors. Channel lists come from the store.
const config = {
  tiktok: { get channels() { return D.tiktok; } },
  twitch: { get channels() { return D.twitch.extra; }, get on() { return D.twitch.on; } },
  youtube: { get channels() { return D.youtube; } },
  kick: { get channels() { return D.kick; } },
};

const clients = new Set();
const history = []; // kept in time order, saved to data/history.json so past messages survive a restart
const seen = new Set();
const KEEP = 5000, MAX_AGE = 7 * 24 * 3600 * 1000;
const HIST = path.join(__dirname, 'data', 'history.json');
try {
  const old = JSON.parse(fs.readFileSync(HIST, 'utf8'));
  old.filter((m) => m && m.id && m.ts > Date.now() - MAX_AGE).sort((a, b) => a.ts - b.ts).slice(-KEEP).forEach((m) => { history.push(m); seen.add(m.id); });
} catch {}
let dirty = false;
function saveHistory(sync) {
  dirty = false;
  const json = JSON.stringify(history.slice(-KEEP)), tmp = HIST + '.tmp';
  try {
    fs.mkdirSync(path.dirname(HIST), { recursive: true });
    if (sync) { fs.writeFileSync(tmp, json); fs.renameSync(tmp, HIST); }
    else fs.writeFile(tmp, json, (e) => { if (!e) fs.rename(tmp, HIST, () => {}); });
  } catch {}
}
setInterval(() => { if (dirty) saveHistory(false); }, 5000).unref();
const audit = [];
const statusMap = {};
const LOG = path.join(__dirname, 'data', 'actions.log');

const broadcast = (o) => { const s = JSON.stringify(o); for (const c of clients) if (c.readyState === 1) c.send(s); };

function emit(o) {
  if (o.type === 'chat') {
    if (seen.has(o.id)) return;
    seen.add(o.id);
    let i = history.length; while (i > 0 && history[i - 1].ts > o.ts) i--; // older (backfilled) messages slot in by time
    history.splice(i, 0, o);
    while (history.length > KEEP) seen.delete(history.shift().id);
    dirty = true;
  } else if (o.type === 'removed') {
    const h = history.find((m) => m.id === o.id); if (h) { h.removed = true; dirty = true; }
  } else if (o.type === 'userRemoved') {
    history.forEach((m) => { if (m.platform === o.platform && m.userId === o.userId && (!o.channel || m.channel === o.channel)) m.removed = true; });
    dirty = true;
  }
  broadcast(o);
}
function status(platform, state, detail = '') { console.log('[status]', platform, state, detail); statusMap[platform] = { state, detail }; broadcast({ type: 'status', status: statusMap }); }

function channelList() {
  const out = [];
  if (connectors.twitch) out.push(...connectors.twitch.list().map((c) => ({ platform: 'twitch', ...c })));
  D.youtube.forEach((c) => out.push({ platform: 'youtube', channel: c.name, key: c.videoId, on: true, source: 'added' }));
  D.kick.forEach((c) => out.push({ platform: 'kick', channel: c.slug, key: c.slug, on: true, source: 'added' }));
  D.tiktok.forEach((c) => out.push({ platform: 'tiktok', channel: c, key: c, on: true, source: 'added' }));
  return out;
}
const pushChannels = () => broadcast({ type: 'channels', channels: channelList() });

const connectors = {};
for (const p of ['twitch', 'youtube', 'kick', 'tiktok']) {
  if (config[p]) connectors[p] = require('./connectors/' + p)({ config, emit, status });
}

/* ---------- adding and removing chats (done from the dashboard) ---------- */
const parse = {
  twitch: (s) => (s.match(/^(?:https?:\/\/)?(?:www\.)?(?:twitch\.tv\/)?@?([A-Za-z0-9_]{3,25})\/?(?:\?.*)?$/) || [])[1]?.toLowerCase(),
  kick: (s) => (s.match(/^(?:https?:\/\/)?(?:www\.)?(?:kick\.com\/)?@?([A-Za-z0-9_-]{3,25})\/?(?:\?.*)?$/) || [])[1]?.toLowerCase(),
  tiktok: (s) => (s.match(/^(?:https?:\/\/)?(?:www\.)?(?:tiktok\.com\/)?@?([A-Za-z0-9_.]{2,24})(?:\/live)?\/?(?:\?.*)?$/) || [])[1],
  youtube: (s) => (s.match(/(?:v=|youtu\.be\/|\/live\/|\/embed\/)([A-Za-z0-9_-]{11})/) || s.match(/^([A-Za-z0-9_-]{11})$/) || [])[1],
};
const NAMES = { twitch: 'Twitch', youtube: 'YouTube', kick: 'Kick', tiktok: 'TikTok' };

async function addChat(p, input) {
  if (!connectors[p]) throw new Error(`${NAMES[p]} is not available in this copy of ModDeck`);
  if (p !== 'tiktok' && !session.loggedIn(p)) throw new Error(`Sign in to ${NAMES[p]} first`);
  const v = parse[p](input.trim());
  if (!v) throw new Error({
    youtube: 'Paste the link to the live stream, for example youtube.com/watch?v=...',
    twitch: 'Type the channel name or paste its link', kick: 'Type the channel name or paste its link', tiktok: 'Type the username or paste the link',
  }[p]);
  if (p === 'twitch') {
    if (!(await connectors.twitch.lookup(v))) throw new Error('Twitch has no channel called ' + v);
    if (!D.twitch.extra.includes(v)) D.twitch.extra.push(v);
    if (D.twitch.on && !D.twitch.on.includes(v)) D.twitch.on.push(v);
  } else if (p === 'youtube') {
    const info = await connectors.youtube.describe(v);
    if (!D.youtube.some((c) => c.videoId === v)) D.youtube.push({ name: info.name, videoId: v });
  } else if (p === 'kick') {
    await connectors.kick.check(v);
    if (!D.kick.some((c) => c.slug === v)) D.kick.push({ slug: v, chatroomId: 0 });
  } else if (!D.tiktok.includes(v)) D.tiktok.push(v);
  store.save();
  await connectors[p].restart();
  pushChannels();
}

async function removeChat(p, key) {
  if (p === 'twitch') {
    D.twitch.extra = D.twitch.extra.filter((c) => c !== key);
    if (D.twitch.on) D.twitch.on = D.twitch.on.filter((c) => c !== key);
  } else if (p === 'youtube') D.youtube = D.youtube.filter((c) => c.videoId !== key);
  else if (p === 'kick') D.kick = D.kick.filter((c) => c.slug !== key);
  else if (p === 'tiktok') D.tiktok = D.tiktok.filter((c) => c !== key);
  store.save();
  await connectors[p].restart();
  pushChannels();
}

async function toggleChat(key, on) { // Twitch only: pick which moderated chats to join
  const cur = D.twitch.on || connectors.twitch.list().filter((c) => c.on).map((c) => c.channel);
  D.twitch.on = on ? [...new Set([...cur, key])] : cur.filter((c) => c !== key);
  store.save();
  await connectors.twitch.restart();
  pushChannels();
}

// Opens a real browser window; the mod signs in the normal way and ModDeck keeps the session.
const signingIn = new Set();
function beginLogin(p) {
  if (!connectors[p] || signingIn.has(p)) return;
  signingIn.add(p);
  status(p, 'connecting', 'Log in in the window that just opened, then click this when you are in');
  session.login(p)
    .then(() => connectors[p].restart())
    .then(pushChannels)
    .catch((e) => { console.warn('[login]', p, 'failed:', e.message); status(p, 'login', e.message); })
    .finally(() => signingIn.delete(p));
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const send = (code, body, type = 'text/html; charset=utf-8') => { res.writeHead(code, { 'Content-Type': type }); res.end(body); };
  try {
    if (u.pathname === '/') return send(200, fs.readFileSync(path.join(__dirname, 'public', 'index.html')));

    const dn = u.pathname.match(/^\/auth\/(twitch|youtube|kick)\/done$/);
    if (dn) {
      if (req.headers['sec-fetch-site'] === 'cross-site') return send(403, 'Forbidden', 'text/plain');
      session.finish(dn[1]);
      res.writeHead(302, { Location: '/' });
      return res.end();
    }
    const m = u.pathname.match(/^\/auth\/(twitch|youtube|kick)$/);
    if (m) {
      if (req.headers['sec-fetch-site'] === 'cross-site') return send(403, 'Forbidden', 'text/plain');
      beginLogin(m[1]);
      res.writeHead(302, { Location: '/' });
      return res.end();
    }
    send(404, 'Not found', 'text/plain');
  } catch (e) { send(500, e.message, 'text/plain'); }
});

// Only pages served by this server may connect. This stops other websites you
// visit from sending ban commands to your local dashboard.
const wss = new WebSocketServer({
  server, path: '/ws',
  verifyClient: ({ origin }) => ['http://localhost:' + PORT, 'http://127.0.0.1:' + PORT].includes(origin),
});

const KINDS = new Set(['delete', 'timeout', 'ban', 'unban', 'warn']);

wss.on('connection', (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify({ type: 'init', channels: channelList(), status: statusMap, history, audit }));
  ws.on('close', () => clients.delete(ws));
  ws.on('message', async (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'say') {
      const limit = m.platform === 'youtube' ? 200 : 500;
      const text = String(m.text || '').trim();
      let error;
      try {
        if (!text) return;
        if (!connectors[m.platform] || !channelList().some((c) => c.platform === m.platform && c.channel === m.channel && c.on)) throw new Error('Unknown chat');
        if (text.length > limit) throw new Error(`Too long for ${m.platform} (max ${limit} characters)`);
        await connectors[m.platform].say(m.channel, text);
      } catch (e) { error = e.message; }
      ws.send(JSON.stringify({ type: 'sayResult', reqId: m.reqId, ok: !error, error, channel: m.channel }));
      return;
    }
    if (m.type === 'addChat' || m.type === 'removeChat' || m.type === 'toggleChat' || m.type === 'signOut') {
      const p = m.platform;
      try {
        if (!NAMES[p]) return;
        if (m.type === 'addChat') await addChat(p, String(m.input || ''));
        else if (m.type === 'removeChat') await removeChat(p, String(m.key));
        else if (m.type === 'toggleChat' && p === 'twitch' && connectors.twitch) await toggleChat(String(m.key), !!m.on);
        else if (m.type === 'signOut' && connectors[p] && p !== 'tiktok') {
          connectors[p].stop(); await session.signOut(p);
          status(p, 'login', 'Signed out'); pushChannels();
        }
      } catch (e) { ws.send(JSON.stringify({ type: 'toast', bad: true, text: e.message })); }
      return;
    }
    if (m.type === 'lookup') {
      let found = null;
      try {
        const c = connectors[m.platform];
        if (c && c.lookup && /^[A-Za-z0-9_]{1,25}$/.test(m.name || '')) found = await c.lookup(m.name);
      } catch {}
      ws.send(JSON.stringify({ type: 'lookupResult', reqId: m.reqId, platform: m.platform, found }));
      return;
    }
    if (m.type === 'multi') {
      const a = m.action || {};
      if (!['ban', 'timeout', 'warn', 'unban'].includes(a.kind) || !Array.isArray(m.targets)) return;
      const action = {
        kind: a.kind, all: true,
        duration: Math.min(1209600, Math.max(1, Number(a.duration) || 600)),
        reason: String(a.reason || '').slice(0, 500),
      };
      const results = [];
      for (const t of m.targets.slice(0, 10)) {
        const c = connectors[t.platform];
        if (!c || !t.userId) continue;
        let rs;
        try { rs = await c.act(action, { platform: t.platform, userId: String(t.userId), user: String(t.user || ''), channel: '' }); }
        catch (e) { rs = [{ channel: '', ok: false, error: e.message }]; }
        const entry = { ts: Date.now(), kind: action.kind, duration: action.duration, platform: t.platform, user: String(t.user || ''), results: rs };
        audit.unshift(entry); if (audit.length > 100) audit.pop();
        fs.appendFile(LOG, JSON.stringify(entry) + '\n', () => {});
        broadcast({ type: 'audit', entry });
        rs.forEach((r) => results.push({ ...r, platform: t.platform, user: t.user, userId: String(t.userId) }));
      }
      ws.send(JSON.stringify({ type: 'multiResult', reqId: m.reqId, kind: action.kind, results }));
      return;
    }
    if (m.type !== 'action' || !KINDS.has(m.action?.kind) || !connectors[m.msg?.platform]) return;
    const a = m.action;
    a.duration = Math.min(1209600, Math.max(1, Number(a.duration) || 600));
    a.reason = String(a.reason || '').slice(0, 500);
    let results;
    try { results = await connectors[m.msg.platform].act(a, m.msg); }
    catch (e) { results = [{ channel: m.msg.channel, ok: false, error: e.message }]; }
    const entry = { ts: Date.now(), kind: a.kind, duration: a.duration, platform: m.msg.platform, user: m.msg.user, results };
    audit.unshift(entry); if (audit.length > 100) audit.pop();
    fs.appendFile(LOG, JSON.stringify(entry) + '\n', () => {});
    ws.send(JSON.stringify({ type: 'result', reqId: m.reqId, results }));
    broadcast({ type: 'audit', entry });
  });
});

function openBrowser(url) {
  if (process.argv.includes('--no-open')) return;
  const cmd = process.platform === 'win32' ? `start "" "${url}"` : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  require('child_process').exec(cmd, () => {});
}

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') { console.log(`ModDeck is already running. Opening http://localhost:${PORT}`); openBrowser(`http://localhost:${PORT}`); process.exit(0); }
  throw e;
});

server.listen(PORT, 'localhost', () => {
  const url = `http://localhost:${PORT}`;
  console.log(`ModDeck is running at ${url}`);
  for (const [p, c] of Object.entries(connectors)) c.start().then(pushChannels).catch((e) => status(p, 'error', e.message));
  openBrowser(url);
});

const quit = () => { saveHistory(true); session.closeAll().finally(() => process.exit(0)); };
process.on('SIGINT', quit);
process.on('SIGTERM', quit);
