@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ModDeck needs Node.js. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Setting up ModDeck for the first time...
  call npm install
)
node server.js
pause
