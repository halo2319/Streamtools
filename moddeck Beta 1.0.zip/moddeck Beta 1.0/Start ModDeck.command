#!/bin/sh
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "ModDeck needs Node.js. Install it from https://nodejs.org and run this again."
  read -r _
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Setting up ModDeck for the first time..."
  npm install
fi
node server.js
