// YouTube: reads and moderates live chat through the same web endpoints youtube.com
// itself uses, signed in as the moderator's own session (no API key, no quota).
// These are unofficial and can change without notice.
const crypto = require('crypto');
const session = require('../lib/session');

const ORIGIN = 'https://www.youtube.com';

function parseAt(html, s) {
  let depth = 0, str = false, esc = false;
  for (let k = s; k < html.length; k++) {
    const ch = html[k];
    if (str) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') str = false; continue; }
    if (ch === '"') str = true;
    else if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) { try { return JSON.parse(html.slice(s, k + 1)); } catch { return null; } }
  }
  return null;
}
// ytInitialData can be mentioned several times in a page, and is written either as a plain object
// or as JSON.parse('\x7b...') with escaped text. Try every mention until a real object parses.
function unescapeJs(body) {
  const j = body.replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => '\\u00' + h).replace(/\\'/g, "'");
  return JSON.parse(JSON.parse('"' + j + '"'));
}
function extractJson(html, marker) {
  let i = -1;
  while ((i = html.indexOf(marker, i + 1)) >= 0) {
    const tail = html.slice(i + marker.length, i + marker.length + 40);
    try {
      let m;
      if ((m = tail.match(/^["\]\s=]*\{/))) {
        const o = parseAt(html, i + marker.length + m[0].length - 1);
        if (o && typeof o === 'object' && Object.keys(o).length > 1) return o;
      } else if ((m = tail.match(/^["\]\s=]*JSON\.parse\(\s*'/))) {
        const st = i + marker.length + m[0].length;
        let k = st; while (k < html.length && !(html[k] === "'" && html[k - 1] !== '\\')) k++;
        const o = unescapeJs(html.slice(st, k));
        if (o && typeof o === 'object') return o;
      }
    } catch {}
  }
  return null;
}
const runsText = (m) => (m?.runs || []).map((r) => r.text ?? r.emoji?.shortcuts?.[0] ?? r.emoji?.emojiId ?? '').join('') || m?.simpleText || '';

module.exports = ({ config, emit, status }) => {
  const cfg = config.youtube;
  const chats = new Map(); // name -> { videoId, st }
  const ctxParams = new Map(); // message id -> context-menu params
  const lastByUser = new Map(); // `${chat}:${userId}` -> params
  let stopped = true;

  let logged = false;
  async function authHeaders() {
    // A browser only sends youtube.com's own cookies to youtube.com. The saved login also holds google.com cookies
    // with the same names (SAPISID, SID...) but different values, and mixing them makes YouTube treat us as signed out.
    const now = Date.now() / 1000;
    const jar = new Map();
    for (const c of await session.cookies('youtube')) {
      const d = String(c.domain || '').replace(/^\./, '').toLowerCase();
      if (!(d === 'youtube.com' || d.endsWith('.youtube.com'))) continue;
      if (c.expires > 0 && c.expires < now) continue;
      const old = jar.get(c.name);
      if (!old || (String(c.domain).startsWith('.') && !String(old.domain).startsWith('.'))) jar.set(c.name, c);
    }
    const get = (n) => jar.get(n)?.value;
    if (!logged) { logged = true; console.log('[youtube] sending', jar.size, 'youtube.com cookies | SAPISID:', !!get('SAPISID'), '| __Secure-3PAPISID:', !!get('__Secure-3PAPISID')); }
    const ts = Math.floor(Date.now() / 1000);
    const h = (sid) => `${ts}_${crypto.createHash('sha1').update(`${ts} ${sid} ${ORIGIN}`).digest('hex')}`;
    const parts = [];
    if (get('SAPISID')) parts.push('SAPISIDHASH ' + h(get('SAPISID')));
    if (get('__Secure-1PAPISID')) parts.push('SAPISID1PHASH ' + h(get('__Secure-1PAPISID')));
    if (get('__Secure-3PAPISID')) parts.push('SAPISID3PHASH ' + h(get('__Secure-3PAPISID')));
    const cookie = [...jar.values()].map((c) => `${c.name}=${c.value}`);
    if (!jar.has('SOCS')) cookie.push('SOCS=CAI');
    if (!jar.has('CONSENT')) cookie.push('CONSENT=YES+1');
    return {
      Authorization: parts.join(' '), 'X-Origin': ORIGIN, 'X-Goog-AuthUser': '0', 'User-Agent': session.ua('youtube'),
      'Content-Type': 'application/json', Origin: ORIGIN, Referer: ORIGIN + '/',
      'X-Youtube-Client-Name': '1', 'X-Youtube-Bootstrap-Logged-In': 'true',
      Cookie: cookie.join('; '), 'Accept-Language': 'en-US,en;q=0.9',
    };
  }

  async function post(st, path, body, query = '') {
    const hdrs = await authHeaders(); hdrs['X-Youtube-Client-Version'] = st.version;
    const r = await fetch(`${ORIGIN}/youtubei/v1/${path}?key=${st.key}&prettyPrint=false${query}`, {
      method: 'POST', headers: hdrs,
      body: JSON.stringify({ context: { client: { clientName: 'WEB', clientVersion: st.version, hl: 'en' } }, ...body }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) console.warn('[youtube] HTTP', r.status, path, JSON.stringify(j.error || j).slice(0, 400));
    if (!r.ok) throw new Error(`${j.error?.message || 'YouTube error'} (${path.split('/').pop()}, HTTP ${r.status})`);
    return j;
  }

  async function describe(videoId) {
    const r = await fetch(`${ORIGIN}/oembed?format=json&url=${encodeURIComponent(ORIGIN + '/watch?v=' + videoId)}`);
    if (!r.ok) throw new Error('YouTube could not find that video');
    return { name: (await r.json()).author_name };
  }

  const FALLBACK_KEY = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'; // YouTube's long-standing public web key
  const fs = require('fs'), path = require('path');
  function dump(name, html) {
    try { fs.writeFileSync(path.join(__dirname, '..', 'data', name), html); } catch {}
  }

  // Every chat feed we can find for the stream: "Live chat" (everything) first, then the default view.
  function continuations(lc) {
    const out = [];
    const subs = lc.header?.liveChatHeaderRenderer?.viewSelector?.sortFilterSubMenuRenderer?.subMenuItems || [];
    const live = subs.find((i) => /live chat/i.test(i.title || '') && !/top/i.test(i.title || ''));
    const fromSub = live?.continuation?.reloadContinuationData?.continuation;
    if (fromSub) out.push(fromSub);
    const c = lc.continuations?.[0] || {};
    const def = (c.invalidationContinuationData || c.timedContinuationData || c.reloadContinuationData || {}).continuation;
    if (def && def !== fromSub) out.push(def);
    return out;
  }
  function findKey(o, key, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 14) return undefined;
    if (o[key]) return o[key];
    for (const k in o) { const r = findKey(o[k], key, depth + 1); if (r) return r; }
  }
  const sendParamsOf = (lc) => findKey(lc?.actionPanel, 'sendLiveChatMessageEndpoint')?.params || findKey(lc, 'sendLiveChatMessageEndpoint')?.params;
  const loggedOutOf = (j) => j?.responseContext?.mainAppWebResponseContext?.loggedOut;
  const versionOf = (j) => {
    for (const sv of j?.responseContext?.serviceTrackingParams || []) for (const p of sv.params || []) if (p.key === 'cver' || p.key === 'client.version') return p.value;
  };

  async function fetchPage(url) {
    const h = await authHeaders(); delete h['Content-Type'];
    const r = await fetch(url, { headers: h, redirect: 'follow' });
    return { r, html: await r.text() };
  }

  // Yields every way of opening this stream's chat, best first. If one is rejected, the loop moves on to the next.
  async function* candidates(ch, entry) {
    entry.why = '';
    const why = (m) => { entry.why += (entry.why ? ' | ' : '') + m; };
    // 1. The API youtube.com itself calls (no page scraping).
    try {
      const j = await post({ key: FALLBACK_KEY, version: '2.20250410.01.00' }, 'next', { videoId: ch.videoId });
      const lc = j?.contents?.twoColumnWatchNextResults?.conversationBar?.liveChatRenderer;
      const list = lc ? continuations(lc) : [];
      console.log('[youtube] YouTube sees this request as', loggedOutOf(j) === true ? 'SIGNED OUT' : loggedOutOf(j) === false ? 'signed in' : 'unknown', '| send button found:', !!(lc && sendParamsOf(lc)));
      if (!list.length) why(lc ? 'api: chat has no continuation' : 'api: video has no live chat (not live, ended, or chat off)');
      for (const cont of list) yield { src: 'api', key: FALLBACK_KEY, version: versionOf(j) || '2.20250410.01.00', continuation: cont, actions: [], sendParams: sendParamsOf(lc), loggedOut: loggedOutOf(j) === true };
    } catch (e) { why('api: ' + e.message); }
    // 2. The chat page and the watch page.
    for (const t of [
      { name: 'popout', url: `${ORIGIN}/live_chat?is_popout=1&v=${ch.videoId}`, get: (d) => d?.contents?.liveChatRenderer },
      { name: 'watch', url: `${ORIGIN}/watch?v=${ch.videoId}`, get: (d) => d?.contents?.twoColumnWatchNextResults?.conversationBar?.liveChatRenderer },
    ]) {
      let page;
      try { page = await fetchPage(t.url); } catch (e) { why(`${t.name} page: ${e.message}`); continue; }
      const { r, html } = page;
      if (/consent\.youtube\.com|consent\.google\.com/.test(r.url)) { why('YouTube is asking for cookie consent. Sign out and sign in again'); continue; }
      const data = extractJson(html, 'ytInitialData');
      const lc = t.get(data);
      if (!lc) {
        const title = (html.match(/<title[^>]*>([^<]{0,80})/i) || [])[1] || '';
        why(`${t.name} page had no chat (HTTP ${r.status}, ${html.length} bytes${title ? ', "' + title.trim() + '"' : ''}${data ? '' : ', no page data'})`);
        dump('yt-debug-' + t.name + '.html', html);
        continue;
      }
      const list = continuations(lc);
      if (!list.length) { why(`${t.name} page: chat has no continuation (chat closed?)`); continue; }
      for (const cont of list) yield {
        src: t.name, continuation: cont, actions: t.name === 'popout' ? (lc.actions || []) : [], sendParams: sendParamsOf(lc),
        key: (html.match(/"INNERTUBE_API_KEY":"([^"]+)"/) || [])[1] || FALLBACK_KEY,
        version: (html.match(/"INNERTUBE_CONTEXT_CLIENT_VERSION":"([^"]+)"/) || [])[1] || '2.20250410.01.00',
      };
    }
  }

  // Returns the entry.skip-th way of opening the chat (skip rises each time one is rejected), or null with entry.why set.
  async function init(ch, entry) {
    let n = 0; entry.ok = false;
    for await (const st of candidates(ch, entry)) {
      if (n++ === (entry.skip || 0)) { entry.tried = n; console.log('[youtube] opening chat for', ch.name, 'via', st.src, '#' + n); entry.why = ''; return st; }
    }
    if (n > 0) { entry.why = `all ${n} ways of opening the chat were rejected by YouTube. ${entry.lastErr || ''}`; entry.skip = 0; }
    console.warn('[youtube] could not open chat for', ch.name, '-', entry.why);
    return null;
  }

  function handle(ch, actions) {
    for (const a of actions) {
      const item = a.addChatItemAction?.item;
      const rd = item?.liveChatTextMessageRenderer || item?.liveChatPaidMessageRenderer;
      if (rd) {
        const params = rd.contextMenuEndpoint?.liveChatItemContextMenuEndpoint?.params;
        if (params) {
          ctxParams.set(rd.id, params); lastByUser.set(`${ch.name}:${rd.authorExternalChannelId}`, params);
          if (ctxParams.size > 4000) ctxParams.delete(ctxParams.keys().next().value);
        }
        const badges = (rd.authorBadges || []).map((b) => b.liveChatAuthorBadgeRenderer?.tooltip || '');
        emit({
          type: 'chat', id: 'youtube:' + rd.id, mid: rd.id, platform: 'youtube', channel: ch.name,
          userId: rd.authorExternalChannelId, user: rd.authorName?.simpleText || 'unknown',
          text: runsText(rd.message) || runsText(rd.headerSubtext), ts: Math.floor(Number(rd.timestampUsec) / 1000) || Date.now(),
          isMod: badges.some((b) => /moderator|owner/i.test(b)),
        });
      }
      const del = a.markChatItemAsDeletedAction?.targetItemId || a.removeChatItemAction?.targetItemId;
      if (del) emit({ type: 'removed', id: 'youtube:' + del });
      const by = a.markChatItemsByAuthorAsDeletedAction?.externalChannelId;
      if (by) emit({ type: 'userRemoved', platform: 'youtube', channel: ch.name, userId: by });
    }
  }

  async function loop(ch) {
    if (stopped || !chats.has(ch.name)) return;
    const entry = chats.get(ch.name);
    let wait = 5000;
    try {
      if (!entry.st) {
        entry.st = await init(ch, entry);
        if (entry.st) { handle(ch, entry.st.actions); entry.st.actions = []; }
        else wait = 15000;
      }
      if (entry.st) {
        const j = await post(entry.st, 'live_chat/get_live_chat', { continuation: entry.st.continuation });
        const lc = j.continuationContents?.liveChatContinuation;
        if (!lc) { console.warn('[youtube] get_live_chat gave no chat:', JSON.stringify(j).slice(0, 300)); throw Object.assign(new Error('chat ended'), { ended: true }); }
        const c = lc.continuations?.[0] || {};
        const n = c.invalidationContinuationData || c.timedContinuationData || c.reloadContinuationData;
        if (!n) throw Object.assign(new Error('chat ended'), { ended: true });
        entry.st.continuation = n.continuation;
        wait = Math.max(3000, n.timeoutMs || 5000);
        const sp = sendParamsOf(lc) || findKey(j, 'sendLiveChatMessageEndpoint')?.params; if (sp) entry.st.sendParams = sp;
        if (entry.st.probing) { entry.st.probing = false; entry.st.live = true; console.log('[youtube] using the full Live chat feed for', ch.name); }
        else if (!entry.st.live && !entry.st.probed) {
          // "Top chat" hides some messages. Moderators need all of them, so try switching to "Live chat" once.
          entry.st.probed = true;
          const subs = lc.header?.liveChatHeaderRenderer?.viewSelector?.sortFilterSubMenuRenderer?.subMenuItems || [];
          const live = subs.find((i) => /live chat/i.test(i.title || '') && !/top/i.test(i.title || '') && !i.selected);
          const c2 = live?.continuation?.reloadContinuationData?.continuation;
          if (c2) { entry.st.backup = entry.st.continuation; entry.st.continuation = c2; entry.st.probing = true; wait = 500; }
        }
        handle(ch, lc.actions || []);
        entry.skip = entry.skip || 0; entry.ok = true;
      }
      const found = [...chats.values()].filter((c) => c.st).length;
      status('youtube', entry.st ? 'live' : 'error', entry.st ? `${found}/${chats.size} chats found` : `${ch.name}: ${entry.why || 'waiting to go live'}`);
    } catch (e) {
      if (entry.st?.probing) { // the full Live chat view was refused: go back to the view that works
        entry.st.probing = false; entry.st.continuation = entry.st.backup; entry.timer = setTimeout(() => loop(ch), 500); return;
      }
      if (e.ended) { entry.st = null; entry.ok = false; entry.why = 'chat ended or was reset, retrying'; wait = 10000; }
      else if (entry.st && !entry.ok) { // rejected before ever working: try the next way of opening this chat
        console.warn('[youtube] chat request rejected:', e.message, '- trying another way');
        entry.lastErr = e.message; entry.skip = (entry.skip || 0) + 1; entry.st = null; wait = 500;
      } else { entry.lastErr = e.message; status('youtube', 'error', e.message); if (entry.st) { entry.st = null; entry.ok = false; } wait = 15000; }
    }
    entry.timer = setTimeout(() => loop(ch), wait);
  }

  async function start() {
    stopped = false;
    if (!session.loggedIn('youtube')) return status('youtube', 'login', 'Sign in with your moderator Google account');
    status('youtube', 'connecting');
    if (!(cfg.channels || []).length) status('youtube', 'live', 'signed in. Add a live stream in Manage chats');
    for (const ch of cfg.channels || []) { chats.set(ch.name, { st: null, timer: null, ch }); loop(ch); }
  }

  function stop() {
    stopped = true;
    for (const c of chats.values()) clearTimeout(c.timer);
    chats.clear();
  }

  const ICONS = { delete: /^DELETE$/, ban: /^REMOVE_CIRCLE$|^BLOCK$/, timeout: /^HOURGLASS|^TIMER|^CLOCK/ };
  const TEXTS = { delete: /remove|delete/i, ban: /hide user|block|ban/i, timeout: /timeout/i };

  async function moderate(kind, params, st) {
    const menu = await post(st, 'live_chat/get_item_context_menu', {}, '&params=' + encodeURIComponent(params));
    const items = (menu.liveChatItemContextMenuSupportedRenderers?.menuRenderer?.items || []).map((i) => i.menuServiceItemRenderer).filter(Boolean);
    const it = items.find((i) => ICONS[kind].test(i.icon?.iconType || '')) || items.find((i) => TEXTS[kind].test(runsText(i.text)));
    const p = it?.serviceEndpoint?.moderateLiveChatEndpoint?.params;
    if (!p) throw new Error("YouTube didn't offer that action here (are you a moderator of this chat?)");
    await post(st, 'live_chat/moderate', { params: p });
  }

  async function act({ kind, all }, msg) {
    if (kind === 'unban') return [{ channel: msg.channel, ok: false, error: 'Undo bans in YouTube Studio (Community > Hidden users)' }];
    if (kind === 'warn') return [{ channel: msg.channel, ok: false, error: 'Not supported on YouTube' }];
    const targets = all && kind !== 'delete' ? [...chats.keys()] : [msg.channel];
    const out = [];
    for (const name of targets) {
      try {
        const entry = chats.get(name);
        if (!entry || !entry.st) throw new Error(name + ' is not live yet');
        const params = kind === 'delete' ? ctxParams.get(msg.mid) : (lastByUser.get(`${name}:${msg.userId}`) || (name === msg.channel ? ctxParams.get(msg.mid) : null));
        if (!params) throw new Error('No recent message from that user here');
        await moderate(kind, params, entry.st);
        out.push({ channel: name, ok: true });
      } catch (e) { out.push({ channel: name, ok: false, error: e.message }); }
    }
    return out;
  }

  async function say(channel, text) {
    const entry = chats.get(channel);
    if (!entry || !entry.st) throw new Error(channel + ' is not live yet');
    if (!entry.st.sendParams && entry.ch) {
      try { // ask YouTube again, now that the chat has been running
        const j = await post(entry.st, 'next', { videoId: entry.ch.videoId });
        entry.st.sendParams = findKey(j, 'sendLiveChatMessageEndpoint')?.params;
        if (loggedOutOf(j) === true) entry.st.loggedOut = true;
      } catch {}
    }
    if (!entry.st.sendParams && entry.ch) {
      try {
        const { html } = await fetchPage(`${ORIGIN}/live_chat?is_popout=1&v=${entry.ch.videoId}`);
        const lc = extractJson(html, 'ytInitialData')?.contents?.liveChatRenderer;
        const sp = lc && sendParamsOf(lc); if (sp) entry.st.sendParams = sp;
      } catch {}
    }
    if (!entry.st.sendParams) throw new Error(entry.st.loggedOut
      ? 'YouTube sees ModDeck as signed out. Click Sign out under YouTube, then sign in again'
      : "YouTube didn't offer a way to post in that chat (it may be subscribers-only, or sign in to YouTube again)");
    const j = await post(entry.st, 'live_chat/send_message', {
      richMessage: { textSegments: [{ text }] }, clientMessageId: crypto.randomUUID(), params: entry.st.sendParams,
    });
    // YouTube's reply includes the message we just posted: show it now rather than at the next poll (emit() ignores the repeat).
    try { handle({ name: channel }, j.actions || []); } catch {}
  }

  return { start, stop, act, say, describe, restart: async () => { stop(); await start(); } };
};
